<div align="center" class= "main"> 
  <img src="https://telegra.ph/file/a3cb3587e86dd31a0bc3d.jpg" width="300" height="300"/>
  <h1>ＺＵＳＹＣＯ - ＭＤ</h1>

<a href="https://github.com/DarkMakerofc"><img title="Creator" src="https://img.shields.io/badge/Creator-Mrnima-red.svg?style=for-the-badge&logo=github"></a>
<br>
<a href="https://github.com/darkmakerofc?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/darkmakerofc?color=green&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/ZUSYCO-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/darkmakerofc/ZUSYCO-MD?color=white&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/ZUSYCO-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/darkmakerofc/ZUSYCO-MD?color=yellow&style=flat-square"></a>
<br><br>
</div>
<div align= "left">

  ### Frok ZUSYCO-MD Repository
<a href="https://github.com/DarkMakerofc/ZUSYCO-MD/fork"><img src="https://i.ibb.co/Yj3tZdZ/fork-zusyco-btn.png" alt="NIMA" border="2" width="155" height="46" ></a>
  ### Link Bot To Your Whatsapp.
  
<a href="https://gpt-qr-code.onrender.com/zusyco"><img src="https://i.ibb.co/FWSfNmb/scan-qr-zusyco-btn.png" alt="SCAN-QR" border="2" width="170" height="40" ></a>

<a href="https://replit.com/@MRNima/ZUSYCO-PAIR-CODE?v=1"><img src="https://i.ibb.co/5BGSVZw/pair-code-btn-zusyco.png" alt="PAIR-CODE" border="2" width="170" height="41" ></a>

  #### Upload QR File
  <i>Upload Your **ZUSYCO-QR.nima** File </i>

  ### DEPLOY USING YOUR HOST
  
> DEPLOY ON HEROKU<br>

◍ Copy This Url, Put Like This <template_link><your_github_link>

      https://heroku.com/deploy?template=

  <br>
  
> DEPLOY ON REPLIT<br>

◍ Import To Replit

<a href="https://replit.com/github/"><img src="https://i.ibb.co/0F5q3Fp/run-on-replit-zusyco-btn.png" alt="--NIMA" border="2" width="170" height="40" ></a>

◍ Deploy Using Template
  
<a href="https://replit.com/@MRNima/ZUSYCO-MD?v=1"><img src="https://i.ibb.co/YNwCMsp/zusyco-replit-template-btn.png" alt="--NIMA" border="2" width="170" height="46" ></a>

<br><br>
#### Youtube Video PlayList
<a href="https://www.youtube.com/playlist?list=PLZ2z7lRgfHwgwfNRLBKDYZkEgd34yc1xi"><img src="https://i.ibb.co/NZ9D5Tz/youtube-playlist-zusyco.jpg" alt="--NIMA" border="2" width="300" height="165" ></a>
<br>

</div>

<br><br>
#### Join Telegram Support Group.
<a href="https://t.me/+_IJSxrsUMD5lYTU1"><img src="https://i.ibb.co/Kj3Knpk/TG-SUPPORT-REPO-LOW-NIMA.png" alt="TG-SUPPORT-REPO-LOW-NIMA" border="2" width="145" height="46" ></a>
<br><br><br><br><br><br><br><br><br><br>

# Author : [@MrNima](https://github.com/darkmakerofc)
